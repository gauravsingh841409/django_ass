from flask import Flask, render_template, request, jsonify
import json

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/submit', methods=['POST'])
def submit():
    # Get form data
    name = request.form['name']
    email = request.form['email']
    mobile = request.form['mobile']
    address = request.form['address']

    # Create a dictionary to store the data
    user_data = {
        'Name': name,
        'Email': email,
        'Mobile No': mobile,
        'Address': address
    }

    # Load existing data from the JSON file (if it exists)
    try:
        with open('data.json', 'r') as json_file:
            data = json.load(json_file)
    except FileNotFoundError:
        data = []

    # Append the new data to the list
    data.append(user_data)

    # Save the updated data back to the JSON file
    with open('data.json', 'w') as json_file:
        json.dump(data, json_file, indent=4)

    return 'Data submitted successfully'

@app.route('/view_data')
def view_data():
    # Load data from the JSON file and return it as a JSON response
    try:
        with open('data.json', 'r') as json_file:
            data = json.load(json_file)
    except FileNotFoundError:
        data = []

    return jsonify(data)

if __name__ == '__main__':
    app.run(debug=True)
